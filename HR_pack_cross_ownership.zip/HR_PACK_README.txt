HR Pack (Cross-Ownership) - Generated 2026-02-18

FILES
1) HR_Taxonomy.json
2) HR_Required_Documents_Matrix.xlsx
3) HR_Policy_Register_Template.xlsx
4) HR_Obligations_Mapping_Template.xlsx

RECOMMENDED FOLDER (single source of truth in Nextcloud)
C:\Users\YasserElshishiny\Nextcloud\Policies & Procedures\_SYSTEM_BASELINE\HR\

WORKFLOW
A) Put all HR artifacts in the folder above (no mixing).
B) Fill Status + EvidenceLinkOrPath in HR_Required_Documents_Matrix.xlsx.
C) Add obligations (laws/regulatory clauses) in HR_Obligations_Mapping_Template.xlsx and link them to DocIDs.
D) Readiness % = average (or weighted) of obligation CoveragePercent.
